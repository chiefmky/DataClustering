//Jonathan Onyumbe
// Phase 4
// Data Clustering

#include <iostream>
#include <fstream>
#include <vector>
#include <string>
#include <ctime>
using namespace std;


class Cluster
{
	vector <vector <double>> points, file, centroids, nearest, contingency;
	vector <double> SE;
	int K, N, D, I;
	double T, maxSE;

public:
	Cluster(int A, int B, int C, int Q, double y, vector <vector <double>> data);
	void movePoints();
	void calcCentroids(int iter);
	void randPartition();
	void minMax();
	void calcCH(int iter);
	void calcSW();
	void calcDB();
	void calcExMeasures();
	void calcExRand();
	void calcExJaccard();
	void calcExFM();

	vector <double> SSE, maxSSE, sumK, trueCluster;
	double CH, SW, DB, TP, FN, FP, TN, exRand, exJaccard, exFM;
	int kMin, kMax, tC;
};

Cluster::Cluster(int A, int B, int C, int Q, double y, vector <vector <double>> data)
{
	K = A;
	tC = A;
	N = B;
	D = (C - 1);
	I = Q;
	T = y;

	file.resize(N, vector<double>(D, 0));
	trueCluster.resize(N, 0);
	for (int i = 0; i < N; i++)
	{
		for (int j = 0; j < D; j++)
		{
			file[i][j] = data[i][j];
		}
		trueCluster[i] = data[i][D];
	}

	int r;

	centroids.resize(K, vector<double>(D, 0));
	SE.resize(K);
	SSE.resize(I);
	maxSSE.resize(D);
	sumK.resize(N);
	points.resize(N, vector<double>(K, 0));

	for (int z = 0; z < K; z++)
	{
		r = rand() % N;
		centroids[z] = file[r];
	}
}

void Cluster::randPartition()
{
	int r, total;
	double sum;

	points.resize(N, vector<double>(K, 0));

	for (int i = 0; i < N; i++)
	{
		r = rand() % K;
		points[i][r] = 1;
	}

	for (int z = 0; z < K; z++)
	{
		for (int j = 0; j < D; j++)
		{
			sum = 0;
			total = 0;
			for (int i = 0; i < N; i++)
			{
				if (points[i][z] == 1)
				{
					sum = sum + file[i][j];
					total++;
				}
			}
			centroids[z][j] = sum / total;
		}
	}
}

void Cluster::minMax()
{
	int r, P = 1, m;
	double diff, max;
	vector <double> mins;
	vector <vector <double>> dist;

	dist.resize(N, vector <double>(K, 0));
	r = rand() % N;
	centroids[0] = file[r];

	do
	{
		for (int i = 0; i < N; i++)
		{
			for (int z = 0; z < P; z++)
			{
				diff = 0;
				for (int j = 0; j < D; j++)
				{
					diff += (file[i][j] - centroids[z][j]) * (file[i][j] - centroids[z][j]);
				}
				dist[i][z] = diff;
			}
		}

		mins.resize(N, 0);

		for (int i = 0; i < N; i++)
		{
			for (int z = 0; z < P; z++)
			{
				if (dist[i][z] < mins[i])
					mins[i] = dist[i][z];
			}
		}

		m = 0;
		max = mins[0];

		for (int i = 0; i < N; i++)
		{
			if (mins[i] > max)
			{
				max = mins[i];
				m = i;
			}
		}

		centroids[P] = file[max];

		P++;

	} while (P < K);

}

void Cluster::movePoints()
{
	double diff;
	double min;
	vector <vector <double>> dist;

	dist.resize(N, vector <double>(K, 0));


	for (int i = 0; i < N; i++)
	{
		points[i][0] = 1;
	}

	for (int i = 0; i < N; i++)
	{
		for (int z = 1; z < K; z++)
		{
			points[i][z] = 0;
		}
	}

	for (int i = 0; i < N; i++)
	{
		for (int z = 0; z < K; z++)
		{
			diff = 0;
			for (int j = 0; j < D; j++)
			{
				diff += (file[i][j] - centroids[z][j]) * (file[i][j] - centroids[z][j]);
			}
			dist[i][z] = diff;
		}
	}



	for (int i = 0; i < N; i++)
	{
		min = dist[i][0];
		for (int z = 1; z < K; z++)
		{
			if (dist[i][z] < min)
			{
				min = dist[i][z];
				for (int c = 0; c < K; c++)
				{
					points[i][c] = 0;
				}
				points[i][z] = 1;
			}
		}
	}


	for (int z = 0; z < K; z++)
	{
		sumK[z] = 0;
		for (int i = 0; i < N; i++)
		{
			sumK[z] += points[i][z];
		}
	}


}

void Cluster::calcCentroids(int iter)
{
	double sum, diff;
	int total;

	for (int z = 0; z < K; z++)
	{
		for (int j = 0; j < D; j++)
		{
			sum = 0;
			total = 0;
			for (int i = 0; i < N; i++)
			{
				if (points[i][z] == 1)
				{
					sum = sum + file[i][j];
					total++;
				}
			}
			centroids[z][j] = sum / total;
		}
		if (sumK[z] == 0)
		{
			centroids[z] = maxSSE;
		}

	}

	maxSE = 0;
	maxSSE = file[0];

	for (int z = 0; z < K; z++)
	{
		diff = 0;
		SE[z] = 0;

		for (int i = 0; i < N; i++)
		{
			sum = 0;
			total = 0;
			for (int j = 0; j < D; j++)
			{
				if (points[i][z] == 1)
				{
					diff += (file[i][j] - centroids[z][j]) * (file[i][j] - centroids[z][j]);
				}
				if (diff > maxSE)
				{
					maxSSE = file[i];
					maxSE = diff;
				}
			}
		}
		SE[z] = diff;
		SSE[iter] += SE[z];
	}


}


vector <vector <double>> readFile(string F, int& N, int& D, int& tC)
{
	int n = 0;
	ifstream inFile;
	vector <vector <double>> file;

	inFile.open(F.c_str());
	inFile >> N;
	inFile >> D;
	inFile >> tC;
	file.resize(N, vector<double>(D, 0));
	for (int i = 0; i < N; i++)
	{
		for (int j = 0; j < D; j++)
		{
			inFile >> file[i][j];
		}
	}

	inFile.close();

	return file;
}

vector <vector <double>> normMM(vector <vector <double>> file, int& N, int& D)
{
	vector <double> min, max;
	vector <vector <double>> normMM;
	normMM.resize(N, vector<double>(D, 0));
	min.resize(D, 0);
	max.resize(D, 0);

	for (int j = 0; j < D; j++)
	{
		min[j] = file[0][j];
		max[j] = file[0][j];
	}

	for (int i = 0; i < N; i++)
	{
		for (int j = 0; j < D; j++)
		{
			if (file[i][j] < min[j])
				min[j] = file[i][j];
			if (file[i][j] > max[j])
				max[j] = file[i][j];
		}
	}

	for (int i = 0; i < N; i++)
	{
		for (int j = 0; j < D; j++)
		{
			if (min[j] == max[j])
				normMM[i][j] = file[i][j];
			else
				normMM[i][j] = ((file[i][j] - min[j]) / (max[j] - min[j]));
		}
	}

	return normMM;
}

vector <vector <double>> normZ(vector <vector <double>> file, int& N, int& D)
{
	vector <double> sum, mean, std, a;
	vector <vector <double>> normZ;
	normZ.resize(N, vector<double>(D, 0));
	sum.resize(D, 0);
	mean.resize(D, 0);
	std.resize(D, 0);
	a.resize(D, 0);

	for (int i = 0; i < N; i++)
	{
		for (int j = 0; j < D; j++)
		{
			sum[j] += file[i][j];
		}
	}

	for (int j = 0; j < D; j++)
	{
		mean[j] = sum[j] / N;
	}

	for (int i = 0; i < N; i++)
	{
		for (int j = 0; j < D; j++)
		{
			a[j] += pow((file[i][j] - mean[j]), 2);
		}
	}

	for (int j = 0; j < D; j++)
	{
		std[j] = sqrt(a[j] / (N - 1));
	}

	for (int i = 0; i < N; i++)
	{
		for (int j = 0; j < D; j++)
		{
			normZ[i][j] = (file[i][j] - mean[j]) / std[j];
		}
	}

	return normZ;
}

void Cluster::calcSW()
{
	vector <double> mMinOut, mMax;
	double diff, near, max;
	int numIn = 0, numOut = 0;

	mMinOut.resize(N);
	mMax.resize(N);
	nearest.resize(N, vector<double>(K, 0));
	SW = 0;

	for (int i = 0; i < N; i++)
	{
		if (points[i][0] == 0)
		{
			nearest[i][0] = 1;
			diff = 0;
			for (int j = 0; j < D; j++)
			{
				diff += (file[i][j] - centroids[0][j]) * (file[i][j] - centroids[0][j]);
			}
			near = diff;
		}
		else
		{
			nearest[i][1] = 1;
			diff = 0;
			for (int j = 0; j < D; j++)
			{
				diff += (file[i][j] - centroids[1][j]) * (file[i][j] - centroids[1][j]);
			}
			near = diff;
		}
		for (int z = 0; z < K; z++)
		{
			diff = 0;
			if (points[i][z] != 1)
			{
				for (int j = 0; j < D; j++)
				{
					diff += (file[i][j] - centroids[z][j]) * (file[i][j] - centroids[z][j]);
				}
				if (diff < near)
				{
					near = diff;
					for (int Z = 0; Z < K; Z++)
						nearest[i][Z] = 0;
					nearest[i][z] = 1;
				}
			}
		}
	}

	for (int i = 0; i < N; i++)
	{
		diff = 0;
		for (int I = 0; I < N; I++)
		{
			if (I != i and points[I] == nearest[i])
			{
				for (int j = 0; j < D; j++)
				{
					diff += abs(file[i][j] - file[I][j]);
					numOut++;
				}
			}
		}
		mMinOut[i] = diff / numOut;
	}

	for (int i = 0; i < N; i++)
	{
		diff = 0;
		for (int I = 0; I < N; I++)
		{
			if (I != i && points[I] == points[i])
			{
				for (int j = 0; j < D; j++)
				{
					diff += abs(file[i][j] - file[I][j]);
					numIn++;
				}
			}
		}
		mMax[i] = diff / (numIn - 1);
	}

	for (int i = 0; i < N; i++)
	{
		if (mMinOut > mMax)
			max = mMinOut[i];
		else
			max = mMax[i];
		SW += ((mMinOut[i] - mMax[i]) / max);
	}

	SW = SW / N;
}

void Cluster::calcCH(int iter)
{
	double trSB = 0;
	vector <double> mu;
	vector <int> count;
	vector <vector <double>> muC, muCT;

	mu.resize(D, 0);
	count.resize(K, 0);
	muC.resize(K, vector<double>(D, 0));
	muCT.resize(D, vector<double>(K, 0));

	for (int j = 0; j < D; j++)
	{
		for (int i = 0; i < N; i++)
		{
			mu[j] += file[i][j];
		}
		mu[j] = mu[j] / N;
	}

	for (int z = 0; z < K; z++)
	{
		for (int j = 0; j < D; j++)
		{
			count[z] = 0;
			for (int i = 0; i < N; i++)
			{
				if (points[i][z] == 1)
				{
					muC[z][j] += file[i][j];
					count[z]++;
				}
			}
			muC[z][j] = (muC[z][j] / count[z]) - mu[j];
		}
	}

	for (int z = 0; z < K; z++)
	{
		for (int j = 0; j < D; j++)
		{
			muCT[j][z] = muC[z][j];
		}
	}


	for (int z = 0; z < K; z++)
	{
		for (int j = 0; j < D; j++)
		{
			if (z == j)
			{
				trSB += count[z] * muC[z][j] * muCT[j][z];
			}
		}
	}

	CH = ((N - K) * trSB) / ((K - 1) * SSE[iter]);
}

void Cluster::calcDB()
{
	double DB = 0;
	vector <int> count;
	vector <double> max, mu, sig;
	vector <vector <double>> sigC, muC;
	vector <vector <double>> DBij;

	count.resize(K);
	mu.resize(K);
	max.resize(K);
	sig.resize(K);
	sigC.resize(K, vector<double>(D, 0));
	muC.resize(K, vector<double>(D, 0));
	DBij.resize(K, vector<double>(K, 0));

	for (int z = 0; z < K; z++)
	{
		for (int j = 0; j < D; j++)
		{
			count[z] = 0;
			for (int i = 0; i < N; i++)
			{
				if (points[i][z] == 1)
				{
					muC[z][j] += file[i][j];
					count[z]++;
				}
			}
			muC[z][j] = (muC[z][j] / count[z]);
		}
	}

	for (int z = 0; z < K; z++)
	{
		for (int j = 0; j < D; j++)
		{
			mu[z] += (muC[z][j] * muC[z][j]);
		}
		mu[z] = mu[z] / D;
	}

	for (int z = 0; z < K; z++)
	{
		for (int j = 0; j < D; j++)
		{
			for (int i = 0; i < N; i++)
			{
				sigC[z][j] += (file[i][j] - muC[z][j]) * (file[i][j] - muC[z][j]);
			}
			sigC[z][j] = sqrt(sigC[z][j] / count[z]);
		}
	}

	for (int z = 0; z < K; z++)
	{
		for (int j = 0; j < D; j++)
		{
			sig[z] += sigC[z][j];
		}
		sig[z] = sig[z] / D;
	}

	for (int z = 0; z < K; z++)
	{
		for (int Z = 0; Z < K; Z++)
		{
			if (Z != z)
			{
				if (mu[z] != mu[Z])
					DBij[z][Z] = (sig[z] + sig[Z]) / (mu[z] - mu[Z]);
			}
		}
	}

	max[0] = DBij[0][1];

	for (int z = 0; z < K; z++)
	{
		for (int Z = 1; Z < K; Z++)
		{
			max[z] = DBij[z][0];
		}
	}

	for (int z = 0; z < K; z++)
	{
		for (int Z = 0; Z < K; Z++)
		{
			if (z != Z && DBij[z][Z] > max[z])
			{
				max[z] = DBij[z][Z];
			}
		}
		DB += max[z];
	}

	DB = DB / K;
	cout << DB << endl;
}

void Cluster::calcExMeasures()
{
	int x = 0;
	TP = 0;
	FN = 0;
	FN = 0;
	TN = 0;
	contingency.resize(2, vector<double>(2, 0));

	for (int i = 0; i < N; i++)
	{
		for (int I = 0; I < N; I++)
		{
			if (i != I && I > i)
			{
				for (int z = 0; z < tC; z++)
				{
					if (points[i][z] == 1)
					{
						if (points[i][z] == points[I][z])
						{
							if (trueCluster[i] == trueCluster[I])
							{
								TP++;
							}
							else
							{
								FP++;
							}
						}
						else
						{
							if (trueCluster[i] == trueCluster[I])
							{
								FN++;
							}
							else
							{
								TN++;
							}
						}
					}
				}
			}
		}
	}
}

void Cluster::calcExRand()
{
	exRand = (TP + TN) / N;
}

void Cluster::calcExJaccard()
{
	exJaccard = TP / (TP + FN + FP);
}

void Cluster::calcExFM()
{
	exFM = TP / sqrt((TP + FN) * (TP + FP));
}

int main()
{
	string F;
	int K, I, R, N, D, iter, end, tC;
	double T, kMin, kMax;
	ofstream outFile;


	cin >> F >> I >> T >> R;
	vector <vector <double>> file, fileNormMM, fileNormZ;

	file = readFile(F, N, D, tC);

	srand(time(NULL));

	outFile.open(F + ".out");



	for (int m = 1; m <= R; m++)
	{
		Cluster clusters = Cluster(tC, N, D, I, T, file);

		iter = 0;
		for (int i = 0; i < I; i++)
		{
			clusters.SSE[i] = 0;
		}

		clusters.movePoints();
		clusters.calcCentroids(iter);
		do {
			iter++;
			clusters.movePoints();
			clusters.calcCentroids(iter);
		} while (iter < I - 1 && (clusters.SSE[iter - 1] - clusters.SSE[iter]) / clusters.SSE[iter - 1] > T);

		clusters.calcExMeasures();
		clusters.calcExRand();
		clusters.calcExJaccard();
		clusters.calcExFM();

		outFile << clusters.exRand << " " << clusters.exJaccard << " " << clusters.exFM << endl;
	}

	cin >> end;
}